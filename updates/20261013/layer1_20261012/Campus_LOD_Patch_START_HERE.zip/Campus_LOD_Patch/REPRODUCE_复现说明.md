# 复现与使用边界

## 直接复用

本包已包含全部修改后的源 blend、所有对应 FBX 和贴图，无需运行修复脚本。verify_bundle.py 可在任何目录通过 --root 指定解压后的包目录，进行只读逐文件哈希核查。

## 从公开基线复算

qa/reproduction/scripts 保存实际执行过的诊断、修复、合并及复验脚本。它们是一组有先后依赖的工程步骤，不是未经验证的一键重建器。不要按文件名批量运行所有脚本；debug、候选比较与历史方法保留用于证据复查。

推荐在新工作目录 R 中安排：scripts/ 为本次脚本；source/Campus_Repair_20261007_r1/ 为公开 r1 八包解压后的原始副本；index/Campus_Repair_20261007_r1/ 为随附基线索引；work/ 为候选和最终副本；reports/、renders/ 为重新生成的记录。脚本以自身 parents[2] 得到 R；少数历史脚本/任务 JSON 使用原执行目录，运行前必须按本地 R 重定向。原始文件应只读保护。

使用 Blender 4.3.2、Python、NumPy、Pillow；Blender 内建 FBX 导入导出和原包 convert_blender_fbx_7500.py 负责正确序列化 FBX 7400/7500。不得只改 FBX 文件头版本号。离线材质渲染使用 Cycles CPU、2 线程、禁用降噪；该构建没有 OpenImageDenoise。

## 已执行的主要顺序

1. 礼拜堂：scripts/chapel/rebuild_structural_lod1.py → finalize_chapel_candidates.py。从经审核的原生成器结构函数重建 LOD1，移除破坏主体的全局减面步骤。
2. Harper 单体：scripts/targeted/finalize_harper.py（调用 sanitize_lod.py），生成 35% 主网格 LOD1，保留双面不同 UV 的反向三角并修复塔顶 UV。
3. Cloister：scripts/targeted/repair_cloister.py。Mansueto：scripts/targeted/repair_mansueto.py，保留真实门户、补两侧四片玻璃。
4. Harper 组合体：scripts/assembly/repair_assembly_harper.py → trim_harper_contact.py；以组合体自身裁切后的 main 为输入，保留与 Wieboldt 的接触裁切。
5. TowerGroup、WomensQuadrangle、Taft、Midway 详见 qa/reports/shapes/REPRODUCE_SHAPE_REPAIRS.md；最终路径与历史废弃候选有明确区分。
6. 在新的完整 r1 副本中执行 scripts/integrate/apply_mesh_overlays.py，并按 targeted_patch_jobs.json、shapes_patch_jobs.json、late_patch_jobs.json、assembly_final_job.json 的来源和执行先后同步。JSON candidate 路径需重定向；礼拜堂完整修复目录通过其 finalize 脚本生成后同步。
7. LOD2 贴图对应通过 scripts/bulk/fix_lod2_texture_paths.py 修复；对新导出文件以路径修补脚本统一真实相对贴图路径和原生源文件元数据。几何、UV、法线、材质、变换不因路径修补改变。
8. 最终核查：scripts/bulk/run_final_audit.py、scripts/shapes/compare_shapes.py / verify_final_all.py、scripts/check_settings.py 和 scripts/integrate/render_final_changed.py；使用对应脚本参数/环境变量指定新目录。全量哈希与零加载失败是基础，仍必须查看异常图和修复图。

由于 Blender 保存头、导出时间戳及软件差异，重新生成文件未必逐字节相同。应比较报告中的对象、三角数、几何/UV/矩阵、贴图内容与视图指标，而不是要求新导出 SHA 与本次成品完全相同。成品 SHA 只用于验证本次下载是否完整。

历史脚本和资产中的旧 QA 文档不会自动变成本次权威验收结论。所有结果依然是离线证据，不能替代 CS2 游戏验收。
