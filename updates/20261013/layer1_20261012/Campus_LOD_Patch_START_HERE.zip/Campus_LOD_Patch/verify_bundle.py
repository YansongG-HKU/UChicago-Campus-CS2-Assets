"""Read-only SHA-256 verification. Run from any directory with Python 3.9+."""
import argparse,hashlib,json,pathlib,sys
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent);a=p.parse_args();root=a.root.resolve()
m=json.loads((root/'asset_manifest.json').read_text(encoding='utf-8'));bad=[]
for row in m:
 f=root/row['path'];h=hashlib.sha256()
 if not f.is_file():bad.append({'path':row['path'],'reason':'missing'});continue
 with f.open('rb') as stream:
  for chunk in iter(lambda:stream.read(4*1024*1024),b''):h.update(chunk)
 if f.stat().st_size!=row['bytes'] or h.hexdigest()!=row['sha256']:bad.append({'path':row['path'],'reason':'content mismatch'})
extra=sorted(str(f.relative_to(root)) for f in (root/'assets').rglob('*') if f.is_file() and str(f.relative_to(root)) not in {x['path'] for x in m})
print(json.dumps({'expected_assets':len(m),'matched_assets':len(m)-len(bad),'failures':bad,'extra_assets':extra,'scope':'Byte integrity only; does not certify game operation.'},ensure_ascii=False,indent=2));sys.exit(bool(bad or extra))
