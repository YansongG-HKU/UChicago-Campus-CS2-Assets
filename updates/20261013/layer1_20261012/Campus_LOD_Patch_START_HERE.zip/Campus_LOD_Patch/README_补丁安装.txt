芝加哥大学校园资产：无损全源差量补丁

此补丁配合公开 campus-20261007-r1 的原始八包，重建本次完整新资产。无需重新运行 Blender 测试。

1. 原始 r1 八包解压合并，保留 Campus_Repair_20261007_r1/assets/。
2. 将所有 Campus_LOD_Patch_XX_of_YY.zip 与启动包解压到同一文件夹，合并为 Campus_LOD_Patch/。这是数据块，不能直接当资产导入。
3. 需要 Python 3.9 或更新版，不需额外库。打开终端运行：
   python apply_delta.py --original "原始r1目录" --output "新资产目录"
   例：python apply_delta.py --original "D:\Campus_Repair_20261007_r1" --output "D:\Campus_Cloud_Offline_Candidate_20261012"
4. 新资产目录必须不存在，且不能置于原目录内部。请准备至少约4GB可用空间。补丁先核对全部7854个原始文件，再复制到新目录、应用差量，最后检查全部最终资产SHA。原始文件不会被修改。
5. 显示 SUCCESS 后，新资产目录就是完整修复版。任何哈希不符会停止，不要强行跳过。中途失败产生的不完整新目录不应使用；检查提示后换一个新输出目录重试。

云端已用相同脚本和分块重建并逐文件核验。这里只证明文件完整性；CS2游戏导入、LOD切换、着色器和性能仍未验证。

原始下载：https://github.com/YansongG-HKU/UChicago-Campus-CS2-Assets/releases/tag/campus-20261007-r1
