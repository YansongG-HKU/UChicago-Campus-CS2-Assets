# Campus Strict 20261013 · public second layer

Final asset inventory: 8,032 files, 3,505,395,608 bytes. This layer requires exactly the 7,940-file 20261012 result of the first public update. Public r1's 7,854-file tree must first receive layer one.

Read README_补丁安装.txt and the repository's updates/20261013/README.md for the complete chain. Installation creates a separate new asset directory and preserves its input. asset_manifest.json is authoritative for bytes; historic in-asset reports do not replace the current manifest.

The public START preserves the tested installer, verifier, parts index, complete asset manifest, and change manifest unchanged. Documentation is adapted for the public two-layer route. Audit reports and visual atlases are separate under audit/20261013/ and atlas/20261013/ in the repository.

Source-asset integrity is not an in-game certification. CS2 import, glass/water shaders, LOD switching, collisions and performance remain untested. Existing per-asset licenses and attribution remain in force.
