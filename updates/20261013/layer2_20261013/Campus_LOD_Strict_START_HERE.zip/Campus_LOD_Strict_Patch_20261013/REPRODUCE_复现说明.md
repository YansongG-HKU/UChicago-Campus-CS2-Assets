# Byte-exact reconstruction

Use the complete public sequence: public campus-20261007-r1 eight ZIPs → first update (7,940 assets) → second update (8,032 assets).

Both layers use content-addressed literal chunks and byte ranges copied from an exactly verified input. No Blender or asset-generation script runs. Parts and assembled delta SHA-256 values remain unchanged from their tested deliveries. Each installer requires a fresh separate output and checks the final file hashes. The original baseline is never edited. A failed run may leave an incomplete fresh output, which must not be used.

The public START's support documents changed, but its installer and asset-affecting inputs did not. Existing full reconstruction receipts apply to those unchanged bytes. See CHAIN_VERIFICATION.json alongside the public chain manifest for the release verification summary. Full offline audit documents are separate in audit/20261013/.
