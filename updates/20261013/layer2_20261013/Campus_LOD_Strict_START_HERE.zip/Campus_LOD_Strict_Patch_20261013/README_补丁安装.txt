校园资产第二层公开补丁：7940 → 8032（2026-10-13）

公开完整更新必须按顺序：r1 的八个资产ZIP（7854文件）→ 第一层12个数据ZIP加START（7940文件）→ 本层21个数据ZIP加START（8032文件）。不可把本层直接用于r1。

1. 保留第一层产生的 Campus_Cloud_Offline_Candidate_20261012，其 assets/ 必须为完整7940文件。
2. 把本层 START 和21个数据ZIP合并解压到一个新的补丁目录，得到 Campus_LOD_Strict_Patch_20261013/，其中含 parts/、parts.json 和 apply_second_delta.py。
3. Python3.9+、标准库即可；无需Blender或游戏。在本补丁目录运行：
   python apply_second_delta.py --original "/path/Campus_Cloud_Offline_Candidate_20261012" --output "/path/Campus_Strict_20261013"
4. 输出目录必须不存在，且与原资产目录分开。程序先校验全部分块及7940基线，再复制到新目录、应用差量并核对8032最终文件SHA。原目录保持不变。出现任何错误立即停止，不使用残留的不完整输出。
5. 成功后可再次只读校验：
   python verify_bundle.py --root "/path/Campus_Strict_20261013"

本层相对7940版修改89文件、增加92文件、删除0文件。最终资产8032文件、3,505,395,608字节。完整公开两层下载和可选自动脚本见仓库 updates/20261013/README.md。原始r1独立保留：
https://github.com/YansongG-HKU/UChicago-Campus-CS2-Assets/releases/tag/campus-20261007-r1

本公开START保留实际复原测试所用安装器、分块索引、全量清单、变更表和校验器的原字节。报告与图册另在仓库 audit/20261013/ 和 atlas/20261013/ 提供，不在本启动包内。

只证明离线资产字节完整性；CS2导入、玻璃/水体、LOD切换、碰撞和性能未运行验收。各资产现有许可、署名、历史资料原样保留。
