"""Read-only full asset SHA-256 verification. Python 3.9+, standard library only."""
import argparse, hashlib, json, pathlib, sys

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=pathlib.Path, default=pathlib.Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / 'asset_manifest.json').read_text(encoding='utf-8'))
    wanted = {row['path'] for row in manifest}
    if len(wanted) != len(manifest):
        raise ValueError('Duplicate manifest paths')
    bad = []
    for row in manifest:
        rel = pathlib.PurePosixPath(row['path'])
        if rel.is_absolute() or '..' in rel.parts or '\\' in row['path'] or ':' in row['path'] or not row['path'].startswith('assets/'):
            raise ValueError('Invalid manifest asset path')
        file = root.joinpath(*rel.parts)
        if not file.is_file():
            bad.append({'path': row['path'], 'reason': 'missing'})
            continue
        digest = hashlib.sha256()
        with file.open('rb') as stream:
            for chunk in iter(lambda: stream.read(4194304), b''):
                digest.update(chunk)
        if file.stat().st_size != row['bytes'] or digest.hexdigest() != row['sha256']:
            bad.append({'path': row['path'], 'reason': 'content mismatch'})
    extra = sorted(file.relative_to(root).as_posix() for file in (root / 'assets').rglob('*') if file.is_file() and file.relative_to(root).as_posix() not in wanted)
    result = {'expected_assets': len(manifest), 'matched_assets': len(manifest) - len(bad), 'failures': bad, 'extra_assets': extra, 'scope': 'Byte integrity only; does not certify CS2 editor/runtime, shaders or performance.'}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return int(bool(bad or extra))

if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print('STOPPED:', exc, file=sys.stderr)
        sys.exit(1)
