"""Rebuild a separate complete asset tree from the verified 2026-10-12 delivery and verified delta parts.
Python 3.9+, standard library only. No network, Blender or game launch.
"""
import argparse,hashlib,json,pathlib,shutil,sys,tempfile,zipfile

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def safe(root,rel):
 if not isinstance(rel,str) or not rel or '\\' in rel or ':' in rel:raise ValueError('Invalid package path: '+str(rel))
 p=pathlib.PurePosixPath(rel)
 if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe package path: '+rel)
 q=(root/pathlib.Path(*p.parts)).resolve()
 if root!=q and root not in q.parents:raise ValueError('Path escapes root: '+rel)
 return q

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--original',required=True,type=pathlib.Path,help='2026-10-12 delivered root containing assets/; exactly 7940 baseline assets');parser.add_argument('--output',required=True,type=pathlib.Path,help='New, nonexistent destination');parser.add_argument('--delta',type=pathlib.Path,help='Optional unsplit delta ZIP; otherwise read adjacent parts.json');args=parser.parse_args()
 original=args.original.resolve();output=args.output.resolve();here=pathlib.Path(__file__).resolve().parent
 if output.exists():raise ValueError('Destination already exists; choose a new folder. Original data will never be overwritten.')
 if output==original or original in output.parents or output in original.parents:raise ValueError('Source and output must be separate sibling trees.')
 if not (original/'assets').is_dir():raise ValueError('--original must contain assets/.')
 with tempfile.TemporaryDirectory(prefix='campus_delta_') as td:
  if args.delta:archive=args.delta.resolve()
  else:
   parts=json.loads((here/'parts.json').read_text(encoding='utf-8'));archive=pathlib.Path(td)/'delta.zip'
   if parts.get('format')!='campus-delta-parts-1' or parts.get('baseline')!='Campus_Cloud_Offline_Candidate_20261012_7940_files':raise ValueError('Incorrect parts format or baseline')
   if parts.get('part_count')!=len(parts['parts']):raise ValueError('Part count mismatch')
   with archive.open('wb') as out:
    for row in parts['parts']:
     p=safe(here,row['path'])
     if not p.is_file() or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:raise ValueError('Missing or incorrect patch part: '+row['path'])
     with p.open('rb') as f:shutil.copyfileobj(f,out,4*1024*1024)
   if archive.stat().st_size!=parts['delta_bytes'] or digest(archive)!=parts['delta_sha256']:raise ValueError('Combined delta size/hash mismatch.')
  with zipfile.ZipFile(archive) as z:
   manifest=json.loads(z.read('delta_manifest.json'))
   if manifest['format']!='campus-content-delta-1' or manifest['baseline']!='Campus_Cloud_Offline_Candidate_20261012_7940_files':raise ValueError('Unsupported patch or wrong baseline')
   print('Checking all 2026-10-12 baseline assets before creating output...',flush=True)
   expected=manifest['original_manifest']
   if len(expected)!=7940 or len({r['path'] for r in expected})!=7940:raise ValueError('Incorrect baseline asset count')
   final_rows=manifest.get('output_manifest')
   if not final_rows or len({r['path'] for r in final_rows})!=len(final_rows):raise ValueError('Missing or duplicate full output manifest')
   if any(not r['path'].startswith('assets/') for r in expected+final_rows+manifest['patched_files']):raise ValueError('Only assets/ paths may be reconstructed')
   for i,row in enumerate(expected,1):
    p=safe(original,row['path'])
    if not p.is_file() or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:raise ValueError('Baseline differs from the verified 2026-10-12 delivery: '+row['path'])
    if i%1000==0:print('Baseline checked',i,'/',len(expected),flush=True)
   # Only the audited baseline asset tree is copied. Other unrelated files are not included.
   output.mkdir(parents=True)
   print('Copying original assets to the new folder...',flush=True)
   for row in expected:
    p=safe(output,row['path']);p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(safe(original,row['path']),p)
   for i,row in enumerate(manifest['patched_files'],1):
    target=safe(output,row['path']);target.parent.mkdir(parents=True,exist_ok=True);tmp=target.with_name(target.name+'.delta-tmp');h=hashlib.sha256();size=0
    with tmp.open('wb') as out:
     for op in row['ops']:
      if op[0]=='C':
       source=safe(original,op[1]);left=op[3]
       with source.open('rb') as stream:
        stream.seek(op[2])
        while left:
         block=stream.read(min(left,4*1024*1024))
         if not block:raise ValueError('Truncated source chunk')
         out.write(block);h.update(block);size+=len(block);left-=len(block)
      elif op[0]=='L':
       block=z.read('literals/'+op[1])
       if hashlib.sha256(block).hexdigest()!=op[1]:raise ValueError('Literal chunk hash mismatch')
       out.write(block);h.update(block);size+=len(block)
      else:raise ValueError('Unknown delta instruction')
    if size!=row['bytes'] or h.hexdigest()!=row['sha256']:raise ValueError('Reconstructed hash mismatch: '+row['path'])
    tmp.replace(target);print('Rebuilt',i,'/',len(manifest['patched_files']),row['path'],flush=True)
   if manifest['output_manifest']:
    print('Verifying the entire reconstructed asset tree...',flush=True)
    for row in manifest['output_manifest']:
     p=safe(output,row['path'])
     if not p.is_file() or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:raise ValueError('Final verification failed: '+row['path'])
    wanted={r['path'] for r in manifest['output_manifest']}
    extra=sorted(p.relative_to(output).as_posix() for p in (output/'assets').rglob('*') if p.is_file() and p.relative_to(output).as_posix() not in wanted)
    if extra:raise ValueError('Unexpected final asset files: '+str(extra))
    (output/'asset_manifest.json').write_text(json.dumps(manifest['output_manifest'],ensure_ascii=False,indent=2),encoding='utf-8')
   # Optional delivery notes beside the installer, never arbitrary unverified executable content.
   for name in ['README_先读我.md','REPRODUCE_复现说明.md','change_manifest.csv','verify_bundle.py']:
    p=here/name
    if p.is_file():shutil.copyfile(p,output/name)
   print('SUCCESS: reconstructed files match the audited final SHA-256. Game acceptance is not implied. Output:',output,flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:print('STOPPED:',e,file=sys.stderr);sys.exit(1)
